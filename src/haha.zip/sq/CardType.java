package sq;

public enum CardType {
    Number, King, Knight, SleepingPotion, Dragon, MagicWand
}
