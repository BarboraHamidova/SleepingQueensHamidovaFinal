package sq;

public class Queen {
    public Integer getPoints(){
        return 15;
    }
}
