package sq;

public class MoveQueen {
    public boolean play(Position targetQueenPosition){
        return true;
    }
}
