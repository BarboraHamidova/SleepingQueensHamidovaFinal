package sq;

import java.util.Map;
import java.util.Optional;

public class PlayerState {
    public Map<Integer, Optional<Card>> cards;
    public Map<Integer, Queen> awokenQueens;


}
