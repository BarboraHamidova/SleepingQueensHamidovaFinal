package sq;

public class GameObservable {
    public void add(GameObserver observer){

    }

    public void addPlayer(Integer playerIdx, GameObserver observer){

    }

    public void remove(GameObserver observer){

    }

    public void notifyAll(GameState message){

    }
}
