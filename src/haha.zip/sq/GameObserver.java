package sq;

public interface GameObserver {
    void notify(String message);
}
