package sq;

public class GameFinished {
}
