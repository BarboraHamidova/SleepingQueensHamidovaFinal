package sq;

public class Tests {
    public static void main(String[] args) {
        DrawingAndTrashPile pile = new DrawingAndTrashPile(10, 1);
        Game game = new Game(5, pile);
    }
}

