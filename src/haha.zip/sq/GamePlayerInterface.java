package sq;

public interface GamePlayerInterface {
    String play(String player, String cards);
}
