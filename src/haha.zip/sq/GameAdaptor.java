package sq;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class GameAdaptor implements GamePlayerInterface {
    private Game game;

    private List<Position> convertStringToPositions(String cards, Integer playerIdx){
        List<Position> positions = new LinkedList<>();
        String[] strings = cards.split(" ");
        HandPosition lastHandPosition = null;
        for(int i = 0; i < strings.length; i++){
            if(strings[i].charAt(0) == 'h' && lastHandPosition == null){
                lastHandPosition = new HandPosition(Character.getNumericValue(strings[i].charAt(1)) - 1, playerIdx);
            }
            else if(strings[i].charAt(0) == 'h'){
                positions.add(new Position(lastHandPosition));
                lastHandPosition = new HandPosition(Character.getNumericValue(strings[i].charAt(1))-1, playerIdx);
            }
            else if(strings[i].charAt(0) == 'a'){
                positions.add(new Position(lastHandPosition, new AwokenQueenPosition(Character.getNumericValue(strings[i].charAt(2)) - 1, Integer.valueOf(strings[i].charAt(1)) - 1)));
                lastHandPosition = null;
            }
            else if(strings[i].charAt(0) == 's'){
                positions.add(new Position(lastHandPosition, new SleepingQueenPosition(Character.getNumericValue(strings[i].charAt(1)) - 1)));
                lastHandPosition = null;
            }
        }
        if(lastHandPosition != null){
            positions.add(new Position(lastHandPosition));
        }
        return positions;
    }

    private String convertGameStateToString(GameState gameState){
        return "";
    }

    public GameAdaptor(Game game){
        this.game = game;
    }

    @Override
    public String play(String player, String cards){
        /*Converts to given format, calls correct implemented function and converts to interface format*/
        Integer playerIdxInt = Integer.valueOf(player) - 1;
        List<Position> cardsPositions = convertStringToPositions(cards, playerIdxInt);
        Optional<GameState> gameState = game.play(playerIdxInt ,cardsPositions);
        if(gameState.isPresent()){
            GameState gS = gameState.get();
            return convertGameStateToString(gS);

        }
        return "Nedostal som gameState";
    }
}
