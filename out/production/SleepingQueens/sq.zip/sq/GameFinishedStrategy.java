package sq;

import java.util.Optional;

public interface GameFinishedStrategy {
    Optional<Integer> isFinished ();
}
