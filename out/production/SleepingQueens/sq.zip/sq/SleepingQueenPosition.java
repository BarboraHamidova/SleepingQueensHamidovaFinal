package sq;

public class SleepingQueenPosition {
    private Integer index;

    public SleepingQueenPosition(Integer index){
        this.index = index;
    }

    Integer getCardIndex (){
        return index;
    }
}
